export interface Surgery {
  doctorId: number;
  endTime: number;
  startTime: number;
  surgeryCategory: string;
  surgeryDate: Date;
  surgeryId: number;
}
