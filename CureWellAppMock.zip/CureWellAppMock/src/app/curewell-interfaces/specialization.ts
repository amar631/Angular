export interface Specialization {
  specializationName: string;
  specializationCode: string;
}
