import { Injectable } from '@angular/core';
import { Doctor } from '../curewell-interfaces/doctor';
import { DoctorSpecialization } from '../curewell-interfaces/doctorspecialization';
import { Specialization } from '../curewell-interfaces/specialization';
import { Surgery } from '../curewell-interfaces/surgery';
import {HttpClient,HttpErrorResponse, HttpHeaders,} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CurewellService {
  constructor(private http: HttpClient) {}

  //GetDoctor
  getDoctors(): Observable<Doctor[]> {
    //To do implement necessary logic
    let tempVar = this.http.get<Doctor[]>('https://localhost:44380/api/CureWell/GetDoctors').pipe(catchError(this.errorHandler));    return tempVar;
    /*return null;*/
  }

  //GetSpecialization
  getAllSpecializations(): Observable<Specialization[]> {
    //To do implement necessary logic
    let variable = this.http.get<Specialization[]>('https://localhost:44380/api/CureWell/GetSpecializations').pipe(catchError(this.errorHandler));
    
    return variable;
    /*return null;*/
  }

  //GetSurgeries
  getSurgeriesForToday(): Observable<Surgery[]> {
    //To do implement necessary logic
    let observableOfTypeInteface = this.http.get<Surgery[]>('https://localhost:44380/api/CureWell/GetAllSurgeryTypeForToday').pipe(catchError(this.errorHandler));
    return observableOfTypeInteface;
  }

  //AddDoctor
  addDoctor(doctorName: string): Observable<boolean> {
    //To do implement necessary logic
    let userObj: Doctor;
    userObj = { doctorId: 0, doctorName: doctorName };
    let obs = this.http.post<boolean>('https://localhost:44380/api/CureWell/AddDoctor', userObj).pipe(catchError(this.errorHandler));
    return obs;
    /*return null;*/
  }

  //EditDoctor
  editDoctorDetails(doctorId: number, doctorName: string): Observable<boolean> {
    //To do implement necessary logic
    return null;
  }

  //editSurgery
  editSurgery(doctorId: number, endTime: number, startTime: number,surgeryCategory: string, surgeryDate: Date,surgeryId: number): Observable<boolean> {
    //To do implement necessary logic
    return null;
  }

  //RemoveDoctor
  deleteDoctor(doctor: Doctor) {
    //To do implement necessary logic
    return null;
  }

  //ErrorHandler
  errorHandler(error: HttpErrorResponse) {
    //To do implement necessary logic
    return throwError(error.message || 'ERROR')
  }
}
