import { Component, OnInit, DoCheck } from '@angular/core';
import { Doctor } from '../../curewell-interfaces/doctor';
import { CurewellService } from '../../curewell-services/curewell.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";


@Component({
  templateUrl: './view-doctor.component.html',
})
export class ViewDoctorComponent implements OnInit {

  doctorList: Doctor[];
  showMsgDiv: boolean = false;
  doctorId: number;
  errorMsg: string;
  status: boolean;

  constructor(private _curewellService: CurewellService, private router: Router) { }

  ngOnInit() {
    //To do implement necessary logic
    this.getDoctor();
  }

  getDoctor() {
  //To do implement necessary logic
    this._curewellService.getDoctors().subscribe(
      res => {
        this.doctorList = res;
        this.showMsgDiv = false;
      },
      resErr => {
        this.doctorList = null;
        this.errorMsg = resErr
      },
      () => console.log("success")

    );
  }

  editDoctorDetails(doctor: Doctor) {
    //To do implement necessary logic

  }

  removeDoctor(doctor: Doctor) {
    //To do implement necessary logic
  }

}
